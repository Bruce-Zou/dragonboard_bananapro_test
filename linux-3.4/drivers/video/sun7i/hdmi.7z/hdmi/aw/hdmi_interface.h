#ifndef __HDMI_INTERFACE_H__
#define __HDMI_INTERFACE_H__

#include "../hdmi_hal.h"


#endif