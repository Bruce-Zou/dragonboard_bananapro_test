#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

MODULE_INFO(intree, "Y");

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0xa81dd850, "module_layout" },
	{ 0xed3c55ff, "cdev_alloc" },
	{ 0x84723aaa, "cdev_del" },
	{ 0xe2ab9d8c, "cdev_init" },
	{ 0xfccbc0ca, "Fb_Init" },
	{ 0xaff5a98e, "audio_set_hdmi_func" },
	{ 0x2e5810c6, "__aeabi_unwind_cpp_pr1" },
	{ 0x31b5d6b6, "malloc_sizes" },
	{ 0x8949858b, "schedule_work" },
	{ 0x4e830a3e, "strnicmp" },
	{ 0x91715312, "sprintf" },
	{ 0xefa3aad6, "kthread_create_on_node" },
	{ 0x7d11c268, "jiffies" },
	{ 0xe707d823, "__aeabi_uidiv" },
	{ 0xfa2a45e, "__memzero" },
	{ 0x5f754e5a, "memset" },
	{ 0xa965730, "audio_set_hdcp_func" },
	{ 0x27e1a049, "printk" },
	{ 0x7c4160ec, "kthread_stop" },
	{ 0xcd57e7b9, "sysfs_create_group" },
	{ 0x7a07a759, "device_create" },
	{ 0xe4e6714c, "platform_device_unregister" },
	{ 0x6d19d005, "platform_driver_register" },
	{ 0x2196324, "__aeabi_idiv" },
	{ 0x2985edac, "cdev_add" },
	{ 0x279fb16d, "kmem_cache_alloc" },
	{ 0x354d78a7, "platform_device_register" },
	{ 0xbc601ad6, "script_get_item" },
	{ 0x9cdc9179, "switch_set_state" },
	{ 0xd62c833f, "schedule_timeout" },
	{ 0x35840cdf, "wake_up_process" },
	{ 0xd2965f6f, "kthread_should_stop" },
	{ 0x37a0cba, "kfree" },
	{ 0xaa022058, "disp_set_hdmi_func" },
	{ 0x8ee1026e, "class_destroy" },
	{ 0x90dfe336, "switch_dev_register" },
	{ 0xefd6cf06, "__aeabi_unwind_cpp_pr0" },
	{ 0xd208f526, "platform_driver_unregister" },
	{ 0x216af481, "__class_create" },
	{ 0x29537c9e, "alloc_chrdev_region" },
	{ 0xe914e41e, "strcpy" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=disp";


MODULE_INFO(srcversion, "587E2034F007B3131EB83F8");
